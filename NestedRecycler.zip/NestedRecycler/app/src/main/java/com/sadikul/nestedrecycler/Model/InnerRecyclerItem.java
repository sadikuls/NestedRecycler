package com.sadikul.nestedrecycler.Model;

/**
 * Created by ASUS on 01-Jan-18.
 */

public class InnerRecyclerItem {
    String name;

    public InnerRecyclerItem(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
